package observer;

public interface Subscriber {
    void update(Object notification);
}
